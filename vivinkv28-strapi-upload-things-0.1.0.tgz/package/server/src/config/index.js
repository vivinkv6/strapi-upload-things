'use strict';

module.exports = {
  default: {
    enabled: true,
  },
  validator() {},
};
