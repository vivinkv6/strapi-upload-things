'use strict';

module.exports = [];
