'use strict';

module.exports = () => {};
