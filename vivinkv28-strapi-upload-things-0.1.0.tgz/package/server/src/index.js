'use strict';

const bootstrap = require('./bootstrap');
const config = require('./config');
const controllers = require('./controllers');
const contentTypes = require('./content-types');
const destroy = require('./destroy');
const middlewares = require('./middlewares');
const policies = require('./policies');
const register = require('./register');
const routes = require('./routes');
const services = require('./services');

module.exports = () => {
  return {
    bootstrap,
    config,
    controllers,
    contentTypes,
    destroy,
    middlewares,
    policies,
    register,
    routes,
    services,
  };
};
