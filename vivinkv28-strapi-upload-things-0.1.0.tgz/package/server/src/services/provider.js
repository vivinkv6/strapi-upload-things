'use strict';

const { createRequire } = require('module');

const appRequire = createRequire(`${process.cwd()}/package.json`);
const { UTApi, UTFile } = appRequire('uploadthing/server');

const DEFAULT_CONTENT_DISPOSITION = 'inline';
const DEFAULT_SIGNED_URL_TTL = 60 * 60;
const DEFAULT_UPLOAD_CONCURRENCY = 1;

const toPositiveInteger = (value, fallback) => {
  const parsed = Number(value);

  if (!Number.isInteger(parsed) || parsed < 1) {
    return fallback;
  }

  return parsed;
};

const buildCustomId = (file) => {
  if (file?.provider_metadata?.uploadthing?.customId) {
    return file.provider_metadata.uploadthing.customId;
  }

  return `${file.hash}${file.ext || ''}`;
};

const getStoredKey = (file) => file?.provider_metadata?.uploadthing?.fileKey;

const getStoredCustomId = (file) => file?.provider_metadata?.uploadthing?.customId;

const normalizeUploadResult = (result) => {
  if (!result) {
    throw new Error('UploadThing returned an empty upload response.');
  }

  if (result.error) {
    throw new Error(`UploadThing upload failed: ${result.error.message}`);
  }

  if (!result.data?.key || !result.data?.ufsUrl) {
    throw new Error('UploadThing upload response is missing the file key or a usable URL.');
  }

  return result.data;
};

const streamToBuffer = async (stream) => {
  const chunks = [];

  for await (const chunk of stream) {
    chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
  }

  return Buffer.concat(chunks);
};

module.exports = (providerOptions = {}) => {
  const {
    token = process.env.UPLOADTHING_TOKEN,
    acl,
    apiUrl,
    ingestUrl,
    logLevel,
    logFormat,
    isDev,
    contentDisposition = DEFAULT_CONTENT_DISPOSITION,
    signedUrlExpiresIn = DEFAULT_SIGNED_URL_TTL,
    uploadConcurrency = DEFAULT_UPLOAD_CONCURRENCY,
    privateFiles = false,
    useCustomId = true,
  } = providerOptions;

  if (!token) {
    throw new Error(
      'Missing UploadThing token. Set `providerOptions.token` or the `UPLOADTHING_TOKEN` environment variable.'
    );
  }

  const utapi = new UTApi({
    token,
    apiUrl,
    ingestUrl,
    logLevel,
    logFormat,
    isDev,
    defaultKeyType: useCustomId ? 'customId' : 'fileKey',
  });

  const resolvedSignedUrlTtl = signedUrlExpiresIn;
  const resolvedUploadConcurrency = Math.min(
    25,
    toPositiveInteger(uploadConcurrency, DEFAULT_UPLOAD_CONCURRENCY)
  );

  const assignUploadDataToFile = (file, uploaded, customId) => {
    const publicUrl = uploaded.ufsUrl;

    file.url = publicUrl;
    file.previewUrl = publicUrl;
    file.provider_metadata = {
      ...(file.provider_metadata || {}),
      uploadthing: {
        fileKey: uploaded.key,
        customId,
        url: publicUrl,
        ufsUrl: uploaded.ufsUrl,
        name: uploaded.name,
        size: uploaded.size,
      },
    };
  };

  const uploadBuffer = async (file, buffer) => {
    const customId = useCustomId ? buildCustomId(file) : undefined;
    const uploadFile = new UTFile([buffer], file.name || `${file.hash}${file.ext || ''}`, {
      customId,
      type: file.mime,
    });

    const result = await utapi.uploadFiles(uploadFile, {
      acl,
      contentDisposition,
      concurrency: resolvedUploadConcurrency,
      metadata: {
        source: 'strapi',
        hash: file.hash,
        ext: file.ext,
        mime: file.mime,
      },
    });

    const uploaded = normalizeUploadResult(result);
    assignUploadDataToFile(file, uploaded, customId);
  };

  return {
    async isPrivate() {
      return privateFiles || acl === 'private';
    },

    async getSignedUrl(file) {
      const keyType = useCustomId && getStoredCustomId(file) ? 'customId' : 'fileKey';
      const key = keyType === 'customId' ? getStoredCustomId(file) : getStoredKey(file);

      if (!key) {
        return file;
      }

      const signed = await utapi.getSignedURL(key, {
        expiresIn: resolvedSignedUrlTtl,
        keyType,
      });

      return {
        url: signed.ufsUrl || signed.url,
      };
    },

    async uploadStream(file) {
      if (!file.stream) {
        throw new Error('Missing file stream');
      }

      const buffer = await streamToBuffer(file.stream);
      await uploadBuffer(file, buffer);
    },

    async upload(file) {
      if (!file.buffer) {
        throw new Error('Missing file buffer');
      }

      await uploadBuffer(file, file.buffer);
    },

    async delete(file) {
      const keyType = useCustomId && getStoredCustomId(file) ? 'customId' : 'fileKey';
      const key = keyType === 'customId' ? getStoredCustomId(file) : getStoredKey(file);

      if (!key) {
        return;
      }

      await utapi.deleteFiles(key, { keyType });
    },
  };
};
