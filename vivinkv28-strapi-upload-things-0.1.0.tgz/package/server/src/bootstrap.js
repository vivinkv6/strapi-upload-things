'use strict';

module.exports = ({ strapi }) => {
  strapi.log.info('[strapi-upload-things] plugin bootstrapped');
};
