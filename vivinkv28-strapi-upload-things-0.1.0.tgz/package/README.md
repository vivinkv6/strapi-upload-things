# @vivinkv28/strapi-upload-things

UploadThing provider for the Strapi Upload plugin.

This package lets Strapi upload Media Library files to UploadThing, store the returned file metadata in Strapi, and remove files from UploadThing when media entries are deleted.

## Features

- Uploads Strapi media files to UploadThing
- Stores the UploadThing file key and custom ID in `provider_metadata`
- Saves the returned `ufsUrl` as the Strapi file URL for Media Library previews
- Supports both buffer uploads and stream uploads
- Supports private files with signed URL generation
- Deletes remote files from UploadThing when Strapi deletes media
- Uses predictable custom IDs by default for easier replace/delete workflows

## Installation

Install the provider from npm in your Strapi project:

```bash
npm install @vivinkv28/strapi-upload-things uploadthing
```

## Required environment variables

Add your UploadThing token to the Strapi app `.env` file:

```bash
UPLOADTHING_TOKEN=your_uploadthing_token
```

## Configuration

Create or update `./config/plugins.ts`:

```ts
export default ({ env }) => ({
  upload: {
    config: {
      provider: '@vivinkv28/strapi-upload-things',
      providerOptions: {
        token: env('UPLOADTHING_TOKEN'),
        acl: env('UPLOADTHING_ACL', 'public-read'),
        privateFiles: env.bool('UPLOADTHING_PRIVATE_FILES', false),
        contentDisposition: env('UPLOADTHING_CONTENT_DISPOSITION', 'inline'),
        signedUrlExpiresIn: env.int('UPLOADTHING_SIGNED_URL_EXPIRES_IN', 3600),
        uploadConcurrency: env.int('UPLOADTHING_UPLOAD_CONCURRENCY', 1),
        useCustomId: env.bool('UPLOADTHING_USE_CUSTOM_ID', true),
        logLevel: env('UPLOADTHING_LOG_LEVEL', 'Info'),
      },
      actionOptions: {
        upload: {},
        uploadStream: {},
        delete: {},
      },
    },
  },
});
```

## Provider options

| Option | Type | Default | Description |
| --- | --- | --- | --- |
| `token` | `string` | `process.env.UPLOADTHING_TOKEN` | UploadThing token used to initialize `UTApi`. |
| `acl` | `string` | `undefined` | Upload access level passed to UploadThing during upload. |
| `privateFiles` | `boolean` | `false` | Marks files as private and enables signed URL resolution. |
| `contentDisposition` | `string` | `'inline'` | Content disposition used when uploading files. |
| `signedUrlExpiresIn` | `number` | `3600` | Signed URL expiration time in seconds for private files. |
| `uploadConcurrency` | `number` | `1` | Upload concurrency passed to UploadThing. Values above `25` are capped. |
| `useCustomId` | `boolean` | `true` | Uses a deterministic UploadThing `customId` based on the Strapi file hash and extension. |
| `apiUrl` | `string` | `undefined` | Optional custom UploadThing API URL. |
| `ingestUrl` | `string` | `undefined` | Optional custom UploadThing ingest URL. |
| `logLevel` | `string` | `undefined` | Optional UploadThing log level. |
| `logFormat` | `string` | `undefined` | Optional UploadThing log format. |
| `isDev` | `boolean` | `undefined` | Optional UploadThing development mode flag. |

## How it works

When a file is uploaded from the Strapi Media Library:

1. The provider sends the file to UploadThing using `UTApi`.
2. The returned `ufsUrl` is stored as the file `url` and `previewUrl` in Strapi.
3. UploadThing metadata is stored in `file.provider_metadata.uploadthing`.
4. When the file is deleted in Strapi, the provider removes it from UploadThing using either the stored `customId` or `fileKey`.

Stored metadata includes:

- `fileKey`
- `customId`
- `url`
- `ufsUrl`
- `name`
- `size`

## Private files

If `privateFiles` is enabled, the provider reports the files as private and asks UploadThing for a signed URL when Strapi needs to serve the asset.

Example:

```env
UPLOADTHING_PRIVATE_FILES=true
UPLOADTHING_SIGNED_URL_EXPIRES_IN=3600
```

## Notes

- By default, `useCustomId` is enabled so file replacement and deletion stay predictable.
- The generated custom ID uses the Strapi file hash and extension.
- Public files use UploadThing's returned `ufsUrl`, which helps Media Library previews work correctly.
- If you use a strict Content Security Policy, make sure your UploadThing asset host is allowed for image and media previews.

## Example environment

```env
UPLOADTHING_TOKEN=your_uploadthing_token
UPLOADTHING_ACL=public-read
UPLOADTHING_PRIVATE_FILES=false
UPLOADTHING_CONTENT_DISPOSITION=inline
UPLOADTHING_SIGNED_URL_EXPIRES_IN=3600
UPLOADTHING_UPLOAD_CONCURRENCY=1
UPLOADTHING_USE_CUSTOM_ID=true
UPLOADTHING_LOG_LEVEL=Info
```

## Requirements

- Node.js `>= 20.0.0`
- Strapi v5

## License

MIT
