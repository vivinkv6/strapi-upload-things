'use strict';

const provider = require('./server/src/services/provider');

module.exports = {
  init: provider,
};
